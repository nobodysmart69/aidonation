import { useQuery } from "@tanstack/react-query";
import { useParams } from "wouter";
import { type Crisis, type Nonprofit } from "@shared/schema";
import NonprofitCard from "@/components/nonprofit-card";
import DonationDialog from "@/components/donation-dialog";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { useState } from "react";

export default function CrisisPage() {
  const { id } = useParams<{ id: string }>();
  const [selectedNonprofit, setSelectedNonprofit] = useState<Nonprofit | null>(
    null
  );

  const { data: crisis, isLoading: isLoadingCrisis } = useQuery<Crisis>({
    queryKey: [`/api/crises/${id}`],
  });

  const { data: nonprofits, isLoading: isLoadingNonprofits } = useQuery<
    Nonprofit[]
  >({
    queryKey: ["/api/nonprofits"],
  });

  if (isLoadingCrisis || isLoadingNonprofits) {
    return (
      <div className="space-y-8">
        <Skeleton className="h-[400px]" />
        <div className="grid gap-4 md:grid-cols-2">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-[200px]" />
          ))}
        </div>
      </div>
    );
  }

  if (!crisis) return <div>Crisis not found</div>;

  return (
    <div className="space-y-8">
      <Card className="overflow-hidden">
        <div className="relative h-96">
          <img
            src={crisis.imageUrl}
            alt={crisis.title}
            className="h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent" />
          <div className="absolute bottom-6 left-6 right-6">
            <div className="space-y-4">
              <Badge
                variant={crisis.severity >= 4 ? "destructive" : "secondary"}
                className="gap-1"
              >
                <AlertTriangle className="h-3 w-3" />
                Severity Level {crisis.severity}/5
              </Badge>
              <h1 className="text-3xl font-bold text-white">{crisis.title}</h1>
              <p className="text-white/90 text-lg max-w-3xl">
                {crisis.description}
              </p>
            </div>
          </div>
        </div>
      </Card>

      <div>
        <h2 className="text-2xl font-semibold mb-6">
          Verified Nonprofits Responding
        </h2>
        <div className="grid gap-4 md:grid-cols-2">
          {nonprofits?.map((nonprofit) => (
            <NonprofitCard
              key={nonprofit.id}
              nonprofit={nonprofit}
              onDonate={() => setSelectedNonprofit(nonprofit)}
            />
          ))}
        </div>
      </div>

      {selectedNonprofit && (
        <DonationDialog
          open={true}
          onClose={() => setSelectedNonprofit(null)}
          nonprofit={selectedNonprofit}
          crisisId={Number(id)}
        />
      )}
    </div>
  );
}
