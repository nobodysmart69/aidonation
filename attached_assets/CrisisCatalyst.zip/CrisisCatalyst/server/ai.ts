import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export async function analyzeCrisisText(text: string): Promise<{
  categories: string[];
  severity: number;
}> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content:
            "You are a crisis analysis expert. Analyze the crisis text and provide relevant categories and a severity rating from 1-5. Respond with JSON in this format: { 'categories': string[], 'severity': number }",
        },
        {
          role: "user",
          content: text,
        },
      ],
      response_format: { type: "json_object" },
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("Empty response from OpenAI");
    }

    const result = JSON.parse(content);
    return {
      categories: result.categories,
      severity: Math.max(1, Math.min(5, Math.round(result.severity))),
    };
  } catch (error) {
    console.error("Failed to analyze crisis text:", error);
    return {
      categories: ["unclassified"],
      severity: 3,
    };
  }
}