import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { analyzeCrisisText } from "./ai";
import { insertCrisisSchema, insertDonationSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all active crises
  app.get("/api/crises", async (_req, res) => {
    const crises = await storage.getCrises();
    res.json(crises.filter((c) => c.active));
  });

  // Get single crisis
  app.get("/api/crises/:id", async (req, res) => {
    const crisis = await storage.getCrisis(Number(req.params.id));
    if (!crisis) {
      return res.status(404).json({ message: "Crisis not found" });
    }
    res.json(crisis);
  });

  // Create new crisis with AI analysis
  app.post("/api/crises", async (req, res) => {
    try {
      const data = insertCrisisSchema.parse(req.body);
      const aiAnalysis = await analyzeCrisisText(
        `${data.title} ${data.description}`
      );
      
      const crisis = await storage.createCrisis({
        ...data,
        aiCategories: aiAnalysis.categories,
        severity: aiAnalysis.severity,
      });
      
      res.json(crisis);
    } catch (error) {
      res.status(400).json({ message: "Invalid crisis data" });
    }
  });

  // Get all nonprofits
  app.get("/api/nonprofits", async (_req, res) => {
    const nonprofits = await storage.getNonprofits();
    res.json(nonprofits);
  });

  // Get single nonprofit
  app.get("/api/nonprofits/:id", async (req, res) => {
    const nonprofit = await storage.getNonprofit(Number(req.params.id));
    if (!nonprofit) {
      return res.status(404).json({ message: "Nonprofit not found" });
    }
    res.json(nonprofit);
  });

  // Create donation
  app.post("/api/donations", async (req, res) => {
    try {
      const data = insertDonationSchema.parse(req.body);
      const donation = await storage.createDonation(data);
      res.json(donation);
    } catch (error) {
      res.status(400).json({ message: "Invalid donation data" });
    }
  });

  // Get donations by crisis
  app.get("/api/crises/:id/donations", async (req, res) => {
    const donations = await storage.getDonationsByCrisis(Number(req.params.id));
    res.json(donations);
  });

  // Get analytics data
  app.get("/api/analytics", async (_req, res) => {
    const [crises, donations] = await Promise.all([
      storage.getCrises(),
      storage.getDonations(),
    ]);

    const totalDonations = donations.reduce((sum, d) => sum + d.amount, 0);
    const activeCrises = crises.filter((c) => c.active).length;
    const donationsByCategory = crises.reduce((acc, crisis) => {
      const crisisDonations = donations
        .filter((d) => d.crisisId === crisis.id)
        .reduce((sum, d) => sum + d.amount, 0);
      
      crisis.aiCategories.forEach((category) => {
        acc[category] = (acc[category] || 0) + crisisDonations;
      });
      return acc;
    }, {} as Record<string, number>);

    res.json({
      totalDonations,
      activeCrises,
      donationsByCategory,
    });
  });

  const httpServer = createServer(app);
  return httpServer;
}
