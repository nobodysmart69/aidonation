import CrisisFeed from "@/components/crisis-feed";

export default function Dashboard() {
  return (
    <div className="space-y-8">
      <div className="max-w-3xl">
        <h1 className="text-4xl font-bold mb-4">
          Make an Impact Today
        </h1>
        <p className="text-muted-foreground text-lg">
          Support verified nonprofits providing immediate relief in crisis zones.
          All donations are processed securely through The Giving Block.
        </p>
      </div>

      <CrisisFeed />
    </div>
  );
}
