import { type Crisis, type InsertCrisis, type Nonprofit, type InsertNonprofit, type Donation, type InsertDonation } from "@shared/schema";

export interface IStorage {
  // Crisis methods
  getCrises(): Promise<Crisis[]>;
  getCrisis(id: number): Promise<Crisis | undefined>;
  createCrisis(crisis: InsertCrisis): Promise<Crisis>;
  updateCrisisActive(id: number, active: boolean): Promise<void>;

  // Nonprofit methods
  getNonprofits(): Promise<Nonprofit[]>;
  getNonprofit(id: number): Promise<Nonprofit | undefined>;
  createNonprofit(nonprofit: InsertNonprofit): Promise<Nonprofit>;

  // Donation methods
  getDonations(): Promise<Donation[]>;
  createDonation(donation: InsertDonation): Promise<Donation>;
  getDonationsByCrisis(crisisId: number): Promise<Donation[]>;
}

export class MemStorage implements IStorage {
  private crises: Map<number, Crisis>;
  private nonprofits: Map<number, Nonprofit>;
  private donations: Map<number, Donation>;
  private currentId: { [key: string]: number };

  constructor() {
    this.crises = new Map();
    this.nonprofits = new Map();
    this.donations = new Map();
    this.currentId = { crisis: 1, nonprofit: 1, donation: 1 };

    // Add sample data
    this.initializeSampleData();
  }

  private initializeSampleData() {
    const sampleNonprofits: InsertNonprofit[] = [
      {
        name: "Global Relief Initiative",
        description: "Providing immediate assistance in crisis zones",
        logoUrl: "https://images.unsplash.com/photo-1595547131329-3bc81af45c47",
        cryptoAddress: "0x123...",
        verified: true,
      },
      {
        name: "Crisis Response Team",
        description: "First responders in disaster areas",
        logoUrl: "https://images.unsplash.com/photo-1519276649662-7bd2db2658fe",
        cryptoAddress: "0x456...",
        verified: true,
      },
    ];

    const sampleCrises: InsertCrisis[] = [
      {
        title: "Flood Emergency in Southeast Asia",
        description: "Severe flooding has displaced thousands of residents",
        location: "Southeast Asia",
        severity: 4,
        imageUrl: "https://images.unsplash.com/photo-1653389526309-f8e2e75f8aaf",
        aiCategories: ["natural disaster", "flooding", "humanitarian"],
        active: true,
      },
      {
        title: "Earthquake Response Needed",
        description: "7.2 magnitude earthquake causes widespread damage",
        location: "Central America",
        severity: 5,
        imageUrl: "https://images.unsplash.com/photo-1642942552676-a02d4f94c727",
        aiCategories: ["natural disaster", "earthquake", "infrastructure"],
        active: true,
      },
    ];

    sampleNonprofits.forEach((nonprofit) => this.createNonprofit(nonprofit));
    sampleCrises.forEach((crisis) => this.createCrisis(crisis));
  }

  // Crisis methods
  async getCrises(): Promise<Crisis[]> {
    return Array.from(this.crises.values());
  }

  async getCrisis(id: number): Promise<Crisis | undefined> {
    return this.crises.get(id);
  }

  async createCrisis(crisis: InsertCrisis): Promise<Crisis> {
    const id = this.currentId.crisis++;
    const newCrisis: Crisis = {
      ...crisis,
      id,
      aiCategories: Array.from(crisis.aiCategories),
      active: crisis.active ?? true,
    };
    this.crises.set(id, newCrisis);
    return newCrisis;
  }

  async updateCrisisActive(id: number, active: boolean): Promise<void> {
    const crisis = this.crises.get(id);
    if (crisis) {
      this.crises.set(id, { ...crisis, active });
    }
  }

  // Nonprofit methods
  async getNonprofits(): Promise<Nonprofit[]> {
    return Array.from(this.nonprofits.values());
  }

  async getNonprofit(id: number): Promise<Nonprofit | undefined> {
    return this.nonprofits.get(id);
  }

  async createNonprofit(nonprofit: InsertNonprofit): Promise<Nonprofit> {
    const id = this.currentId.nonprofit++;
    const newNonprofit: Nonprofit = {
      ...nonprofit,
      id,
      verified: nonprofit.verified ?? false,
    };
    this.nonprofits.set(id, newNonprofit);
    return newNonprofit;
  }

  // Donation methods
  async getDonations(): Promise<Donation[]> {
    return Array.from(this.donations.values());
  }

  async createDonation(donation: InsertDonation): Promise<Donation> {
    const id = this.currentId.donation++;
    const newDonation = { ...donation, id };
    this.donations.set(id, newDonation);
    return newDonation;
  }

  async getDonationsByCrisis(crisisId: number): Promise<Donation[]> {
    return Array.from(this.donations.values()).filter(
      (d) => d.crisisId === crisisId
    );
  }
}

export const storage = new MemStorage();