import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const crises = pgTable("crises", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  location: text("location").notNull(),
  severity: integer("severity").notNull(), // 1-5 scale
  imageUrl: text("image_url").notNull(),
  aiCategories: json("ai_categories").$type<string[]>().notNull(),
  active: boolean("active").notNull().default(true),
});

export const nonprofits = pgTable("nonprofits", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  logoUrl: text("logo_url").notNull(),
  cryptoAddress: text("crypto_address").notNull(),
  verified: boolean("verified").notNull().default(false),
});

export const donations = pgTable("donations", {
  id: serial("id").primaryKey(),
  crisisId: integer("crisis_id").notNull(),
  nonprofitId: integer("nonprofit_id").notNull(),
  amount: integer("amount").notNull(), // In cents
  currency: text("currency").notNull(),
});

export const insertCrisisSchema = createInsertSchema(crises).omit({ id: true });
export const insertNonprofitSchema = createInsertSchema(nonprofits).omit({ id: true });
export const insertDonationSchema = createInsertSchema(donations).omit({ id: true });

export type Crisis = typeof crises.$inferSelect;
export type InsertCrisis = z.infer<typeof insertCrisisSchema>;
export type Nonprofit = typeof nonprofits.$inferSelect;
export type InsertNonprofit = z.infer<typeof insertNonprofitSchema>;
export type Donation = typeof donations.$inferSelect;
export type InsertDonation = z.infer<typeof insertDonationSchema>;
